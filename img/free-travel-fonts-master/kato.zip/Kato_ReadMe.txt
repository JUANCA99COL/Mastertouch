
=== KATO ===

Keith Bates / K-Type © 2001, 2007 (version 3.03)
www.k-type.com    -    info@k-type.com

Originally conceived as two separate Japan-inspired fonts, the upper and lower cases can be mixed at the typographer's own risk.

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------